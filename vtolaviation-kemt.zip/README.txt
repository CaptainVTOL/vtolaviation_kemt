Installation: 

1. Exit Flight Simulator 
2. Extract "vtolaviation-kemt.zip"
3. Move "vtolaviation-kemt" folder to your Flight Simulator "Community" folder
4. Restart MSFS

This airport scenery is for individual use and may not be distributed without author's permission. The scenery is freeware, and not to be used for commercial purposes without author's written consent. 